# PrestadorAki — App do prestador (Flutter)

## Importante: leia antes de rodar

Este código foi escrito num ambiente sandbox que **não conseguiu instalar o
Flutter SDK** (o instalador precisa baixar de `storage.googleapis.com`,
bloqueado pela política de rede daquele ambiente). Ou seja: todo o código
Dart abaixo foi escrito com cuidado e revisado manualmente, mas **nunca foi
compilado nem rodado** — ao contrário do backend (testado de ponta a ponta
contra um Postgres real) e do web-cliente (build de produção validado).

Isso significa que é bem provável que `flutter pub get` ou `flutter run`
apontem 1-2 erros pequenos (import faltando, nome de API que mudou de versão
para versão). São ajustes rápidos, mas não estão garantidos como os outros
dois projetos.

## Passo a passo

Este diretório já vem com `lib/`, `pubspec.yaml` e `analysis_options.yaml` —
mas **sem** as pastas de plataforma (`android/`, `ios/`, etc.), que o
Flutter gera sozinho e que não é seguro escrever à mão. Faça isso primeiro:

```bash
# Dentro desta pasta (onde já estão lib/ e pubspec.yaml):
flutter create --org com.opoutsourcing --project-name prestadoraki .
```

O Flutter detecta que já existem `lib/main.dart` e `pubspec.yaml` e **não
sobrescreve esses arquivos** — ele só preenche o que falta (android/, ios/,
web/, etc). Se ele pedir confirmação para continuar em um diretório não
vazio, confirme.

```bash
flutter pub get
flutter analyze     # aponta qualquer ajuste de API/import necessário
```

## Biometria (login com digital/Face ID)

Adicionamos o pacote `local_auth`. Ele exige duas mudanças nos arquivos
nativos gerados pelo `flutter create` — **já apliquei as duas diretamente
no seu projeto**, então não precisa fazer nada, só não rode `flutter
create .` de novo por cima sem saber disso (ele reescreveria o
`MainActivity.kt` e voltaria a quebrar a biometria no Android):

1. `android/app/.../MainActivity.kt` — precisa estender
   `FlutterFragmentActivity` em vez de `FlutterActivity` (o prompt de
   biometria do Android usa `androidx.fragment` por baixo).
2. `android/app/src/main/AndroidManifest.xml` — precisa da permissão
   `android.permission.USE_BIOMETRIC`.
3. `ios/Runner/Info.plist` — precisa da chave `NSFaceIDUsageDescription`
   (o iOS exige essa string antes de deixar o app usar Face ID).

Se em algum momento você rodar `flutter create .` de novo e a biometria
parar de funcionar no Android, é isso — reaplique a mudança do item 1.

## Rodando contra o backend local

O backend (`../backend/`) precisa estar rodando (`npm run start:dev` ou
`docker compose up`) antes de abrir o app.

- **Emulador Android**: não precisa configurar nada — o app já aponta para
  `http://10.0.2.2:3000/v1`, que é como o emulador enxerga o `localhost` da
  sua máquina.
- **iOS Simulator ou dispositivo físico**: rode com o IP da sua máquina na
  rede local:

  ```bash
  flutter run --dart-define=API_BASE_URL=http://SEU_IP_LOCAL:3000/v1
  ```

## O que já está implementado

- Tela de boas-vindas (`/welcome`) com "Entrar" / "Criar conta", antes do
  login — layout em gradiente com as cores da marca.
- Login e cadastro de prestador, integrados de verdade com `POST
  /auth/login` e `/auth/register` (tokens salvos com `flutter_secure_storage`,
  renovação automática via `/auth/refresh` quando a API responde 401).
- Login por biometria: depois do primeiro login com senha, o dashboard
  oferece ativar "entrar com biometria"; da próxima vez que o app abrir com
  o cadeado ativado, aparece a tela de desbloqueio (`/unlock`) em vez do
  dashboard direto. É um cadeado local do app — a biometria nunca é enviada
  para a API, só decide se o token já salvo pode ser usado.
- Navegação com abas (Início, Clientes, Agenda, Orçamentos) via `go_router`.
- Tela de Clientes: lista (com busca) e cadastro, integrados de verdade com
  `GET/POST /customers`.
- Dashboard, Agenda e Orçamentos: layout pronto, mas com dados
  estáticos/mock — os endpoints correspondentes ainda não existem no
  backend (ver `prestadoraki-backlog.xlsx` para a ordem das próximas
  histórias).

## Estrutura

```
lib/
  core/            # ApiClient, AuthController, TokenStorage, tema visual
  router/          # Configuração do go_router (guards de autenticação)
  features/        # Uma pasta por tela/domínio
  widgets/         # Componentes compartilhados (bottom nav)
```
