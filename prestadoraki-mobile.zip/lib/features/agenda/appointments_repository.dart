import '../../core/api_client.dart';
import 'models/appointment.dart';

/// Repositório do endpoint /appointments (contrato de API). Igual ao
/// CustomersRepository, a filtragem por prestador é implícita — o backend
/// lê o providerId do token JWT.
class AppointmentsRepository {
  AppointmentsRepository(this._api);

  final ApiClient _api;

  Future<List<Appointment>> list({DateTime? from, DateTime? to}) async {
    final result = await _api.get(
      '/appointments',
      query: {
        if (from != null) 'from': _dateOnly(from),
        if (to != null) 'to': _dateOnly(to),
      },
    );
    return (result as List).cast<Map<String, dynamic>>().map(Appointment.fromJson).toList();
  }

  Future<Appointment> create({
    String? customerId,
    required AppointmentType type,
    required DateTime scheduledAt,
    int durationMinutes = 60,
    String? addressText,
    String? observations,
  }) async {
    final result = await _api.post('/appointments', body: {
      if (customerId != null) 'customerId': customerId,
      'type': type.wireValue,
      'scheduledAt': scheduledAt.toUtc().toIso8601String(),
      'durationMinutes': durationMinutes,
      if (addressText != null && addressText.isNotEmpty) 'addressText': addressText,
      if (observations != null && observations.isNotEmpty) 'observations': observations,
    });
    return Appointment.fromJson(result as Map<String, dynamic>);
  }

  Future<void> delete(String id) => _api.delete('/appointments/$id');

  String _dateOnly(DateTime date) =>
      '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
}
