/// Tipos e status espelham os enums `appointment_type`/`appointment_status`
/// do banco (schema.sql) e o contrato de API (openapi.yaml).
enum AppointmentType { visitaTecnica, servico, retorno, reuniao, pagamento, outro }

enum AppointmentStatus { agendado, confirmado, concluido, cancelado }

AppointmentType _typeFromJson(String value) => AppointmentType.values.firstWhere(
      (t) => t.wireValue == value,
      orElse: () => AppointmentType.outro,
    );

AppointmentStatus _statusFromJson(String value) => AppointmentStatus.values.firstWhere(
      (s) => s.wireValue == value,
      orElse: () => AppointmentStatus.agendado,
    );

extension AppointmentTypeWire on AppointmentType {
  String get wireValue => switch (this) {
        AppointmentType.visitaTecnica => 'visita_tecnica',
        AppointmentType.servico => 'servico',
        AppointmentType.retorno => 'retorno',
        AppointmentType.reuniao => 'reuniao',
        AppointmentType.pagamento => 'pagamento',
        AppointmentType.outro => 'outro',
      };

  String get label => switch (this) {
        AppointmentType.visitaTecnica => 'Visita técnica',
        AppointmentType.servico => 'Serviço',
        AppointmentType.retorno => 'Retorno',
        AppointmentType.reuniao => 'Reunião',
        AppointmentType.pagamento => 'Pagamento',
        AppointmentType.outro => 'Outro',
      };
}

extension AppointmentStatusWire on AppointmentStatus {
  String get wireValue => switch (this) {
        AppointmentStatus.agendado => 'agendado',
        AppointmentStatus.confirmado => 'confirmado',
        AppointmentStatus.concluido => 'concluido',
        AppointmentStatus.cancelado => 'cancelado',
      };

  String get label => switch (this) {
        AppointmentStatus.agendado => 'Agendado',
        AppointmentStatus.confirmado => 'Confirmado',
        AppointmentStatus.concluido => 'Concluído',
        AppointmentStatus.cancelado => 'Cancelado',
      };
}

class Appointment {
  Appointment({
    required this.id,
    required this.type,
    required this.scheduledAt,
    required this.durationMinutes,
    required this.status,
    this.customerName,
    this.addressText,
    this.observations,
  });

  factory Appointment.fromJson(Map<String, dynamic> json) => Appointment(
        id: json['id'] as String,
        type: _typeFromJson(json['type'] as String),
        scheduledAt: DateTime.parse(json['scheduledAt'] as String).toLocal(),
        durationMinutes: json['durationMinutes'] as int? ?? 60,
        status: _statusFromJson(json['status'] as String),
        customerName: (json['customer'] as Map<String, dynamic>?)?['name'] as String?,
        addressText: json['addressText'] as String?,
        observations: json['observations'] as String?,
      );

  final String id;
  final AppointmentType type;
  final DateTime scheduledAt;
  final int durationMinutes;
  final AppointmentStatus status;
  final String? customerName;
  final String? addressText;
  final String? observations;
}
