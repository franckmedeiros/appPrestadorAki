import '../../core/api_client.dart';
import 'models/customer.dart';

/// Repositório do endpoint /customers (contrato de API, seção 5). Toda
/// consulta já é implicitamente escopada ao prestador logado — o backend
/// lê o providerId do próprio token JWT, nunca do corpo da requisição.
class CustomersRepository {
  CustomersRepository(this._api);

  final ApiClient _api;

  Future<List<Customer>> list({String? search}) async {
    final result = await _api.get(
      '/customers',
      query: search != null && search.isNotEmpty ? {'search': search} : null,
    );
    final items = (result['items'] as List).cast<Map<String, dynamic>>();
    return items.map(Customer.fromJson).toList();
  }

  Future<Customer> create({
    required String name,
    String? phone,
    String? whatsapp,
    String? email,
    String? addressCity,
    String? addressState,
  }) async {
    final result = await _api.post('/customers', body: {
      'name': name,
      if (phone != null && phone.isNotEmpty) 'phone': phone,
      if (whatsapp != null && whatsapp.isNotEmpty) 'whatsapp': whatsapp,
      if (email != null && email.isNotEmpty) 'email': email,
      if (addressCity != null && addressCity.isNotEmpty) 'addressCity': addressCity,
      if (addressState != null && addressState.isNotEmpty) 'addressState': addressState,
    });
    return Customer.fromJson(result as Map<String, dynamic>);
  }
}
