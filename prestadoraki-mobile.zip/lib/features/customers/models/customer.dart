class Customer {
  Customer({
    required this.id,
    required this.name,
    this.phone,
    this.whatsapp,
    this.email,
    this.addressCity,
    this.addressState,
  });

  factory Customer.fromJson(Map<String, dynamic> json) => Customer(
        id: json['id'] as String,
        name: json['name'] as String,
        phone: json['phone'] as String?,
        whatsapp: json['whatsapp'] as String?,
        email: json['email'] as String?,
        addressCity: json['addressCity'] as String?,
        addressState: json['addressState'] as String?,
      );

  final String id;
  final String name;
  final String? phone;
  final String? whatsapp;
  final String? email;
  final String? addressCity;
  final String? addressState;

  String get locationLabel {
    if (addressCity == null) return '';
    if (addressState == null) return addressCity!;
    return '$addressCity/$addressState';
  }
}
