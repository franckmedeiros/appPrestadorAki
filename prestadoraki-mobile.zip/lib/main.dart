import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'core/api_client.dart';
import 'core/app_theme.dart';
import 'core/auth_controller.dart';
import 'core/biometric_service.dart';
import 'core/token_storage.dart';
import 'features/agenda/appointments_repository.dart';
import 'features/customers/customers_repository.dart';
import 'router/app_router.dart';

/// URL base da API. No emulador Android, 10.0.2.2 aponta para o localhost
/// da máquina host (onde a API do backend/ está rodando via `npm run
/// start`, ver README). No iOS Simulator ou em um dispositivo físico,
/// troque pelo IP da sua máquina na rede local.
const _defaultApiBaseUrl = 'http://10.0.2.2:3000/v1';

// O modo padrão do flutter_secure_storage no Android (uma chave RSA no
// Keystore para CADA valor salvo) é conhecido por travar/dar timeout em
// alguns aparelhos — principalmente depois de reinstalar o app várias
// vezes durante o desenvolvimento, quando sobra uma chave "órfã" no
// Keystore de uma instalação anterior. `encryptedSharedPreferences: true`
// troca isso por uma única chave mestra (via Jetpack Security), que é o
// modo recomendado pelo próprio pacote e evita esse travamento.
const _secureStorageAndroidOptions = AndroidOptions(encryptedSharedPreferences: true);

void main() {
  // Obrigatório sempre que algo usa canais de plataforma (secure storage,
  // local_auth, etc.) antes do runApp() — sem isso, toda chamada nativa
  // feita durante o bootstrap() falha com "Binding has not yet been
  // initialized", e o AuthController cai sempre no catch e trata como
  // "sem sessão salva", mesmo quando existe um login válido guardado.
  WidgetsFlutterBinding.ensureInitialized();

  final apiClient = ApiClient(
    baseUrl: String.fromEnvironment('API_BASE_URL', defaultValue: _defaultApiBaseUrl),
  );
  final authController = AuthController(
    apiClient: apiClient,
    tokenStorage: TokenStorage(
      const FlutterSecureStorage(aOptions: _secureStorageAndroidOptions),
    ),
    biometricService: BiometricService(),
  );
  authController.bootstrap();

  runApp(PrestadorAkiApp(apiClient: apiClient, authController: authController));
}

class PrestadorAkiApp extends StatefulWidget {
  const PrestadorAkiApp({super.key, required this.apiClient, required this.authController});

  final ApiClient apiClient;
  final AuthController authController;

  @override
  State<PrestadorAkiApp> createState() => _PrestadorAkiAppState();
}

class _PrestadorAkiAppState extends State<PrestadorAkiApp> {
  late final GoRouter _router = buildAppRouter(widget.authController);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: widget.authController),
        Provider.value(value: widget.apiClient),
        Provider(create: (context) => CustomersRepository(context.read<ApiClient>())),
        Provider(create: (context) => AppointmentsRepository(context.read<ApiClient>())),
      ],
      child: MaterialApp.router(
        title: 'PrestadorAki',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light(),
        routerConfig: _router,
      ),
    );
  }
}
