import 'package:go_router/go_router.dart';
import '../core/auth_controller.dart';
import '../features/auth/biometric_unlock_screen.dart';
import '../features/auth/login_screen.dart';
import '../features/auth/register_screen.dart';
import '../features/customers/customer_form_screen.dart';
import '../features/customers/customers_list_screen.dart';
import '../features/agenda/agenda_screen.dart';
import '../features/agenda/appointment_form_screen.dart';
import '../features/budgets/budgets_screen.dart';
import '../features/dashboard/dashboard_screen.dart';
import '../features/splash_screen.dart';
import '../features/welcome/welcome_screen.dart';
import '../widgets/app_shell.dart';

const _preAuthRoutes = {'/welcome', '/login', '/register'};

GoRouter buildAppRouter(AuthController authController) {
  return GoRouter(
    initialLocation: '/splash',
    refreshListenable: authController,
    redirect: (context, state) {
      final status = authController.status;
      final location = state.matchedLocation;
      final isPreAuth = _preAuthRoutes.contains(location);
      final isSplash = location == '/splash';
      final isUnlock = location == '/unlock';

      switch (status) {
        case AuthStatus.unknown:
          return isSplash ? null : '/splash';
        case AuthStatus.unauthenticated:
          return isPreAuth ? null : '/welcome';
        case AuthStatus.locked:
          return isUnlock ? null : '/unlock';
        case AuthStatus.authenticated:
          return (isPreAuth || isSplash || isUnlock) ? '/dashboard' : null;
      }
    },
    routes: [
      GoRoute(path: '/splash', builder: (context, state) => const SplashScreen()),
      GoRoute(path: '/welcome', builder: (context, state) => const WelcomeScreen()),
      GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),
      GoRoute(path: '/register', builder: (context, state) => const RegisterScreen()),
      GoRoute(path: '/unlock', builder: (context, state) => const BiometricUnlockScreen()),
      GoRoute(
        path: '/clientes/novo',
        builder: (context, state) => const CustomerFormScreen(),
      ),
      GoRoute(
        path: '/agenda/novo',
        builder: (context, state) => const AppointmentFormScreen(),
      ),
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) => AppShell(navigationShell: navigationShell),
        branches: [
          StatefulShellBranch(routes: [
            GoRoute(path: '/dashboard', builder: (context, state) => const DashboardScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: '/clientes', builder: (context, state) => const CustomersListScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: '/agenda', builder: (context, state) => const AgendaScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: '/orcamentos', builder: (context, state) => const BudgetsScreen()),
          ]),
        ],
      ),
    ],
  );
}
