import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Guarda o par access/refresh token no keystore/keychain do dispositivo
/// (nunca em SharedPreferences em texto puro), conforme a seção 9.4 do
/// documento de arquitetura. Também guarda a preferência de "entrar com
/// biometria" — um cadeado local do app, não uma credencial da API.
class TokenStorage {
  TokenStorage(this._storage);

  final FlutterSecureStorage _storage;

  static const _accessKey = 'prestadoraki.accessToken';
  static const _refreshKey = 'prestadoraki.refreshToken';
  static const _biometricKey = 'prestadoraki.biometricEnabled';

  Future<void> save({required String accessToken, required String refreshToken}) async {
    await _storage.write(key: _accessKey, value: accessToken);
    await _storage.write(key: _refreshKey, value: refreshToken);
  }

  Future<String?> readAccessToken() => _storage.read(key: _accessKey);
  Future<String?> readRefreshToken() => _storage.read(key: _refreshKey);

  Future<void> setBiometricEnabled(bool enabled) =>
      _storage.write(key: _biometricKey, value: enabled ? 'true' : 'false');

  Future<bool> readBiometricEnabled() async =>
      (await _storage.read(key: _biometricKey)) == 'true';

  Future<void> clear() async {
    await _storage.delete(key: _accessKey);
    await _storage.delete(key: _refreshKey);
    await _storage.delete(key: _biometricKey);
  }
}
