import 'package:flutter/foundation.dart';
import 'api_client.dart';
import 'api_exception.dart';
import 'biometric_service.dart';
import 'token_storage.dart';

enum AuthStatus { unknown, authenticated, unauthenticated, locked }

/// Estado de autenticação do app, compartilhado via Provider a partir da
/// raiz (main.dart). Conecta o ApiClient (que só sabe fazer HTTP), o
/// TokenStorage (que só sabe persistir strings) e o BiometricService (que
/// só sabe pedir digital/rosto ao SO) com os endpoints /auth/* do backend
/// (seção 5 do documento de arquitetura).
///
/// `AuthStatus.locked` é um estado que só existe no app — nunca chega a
/// virar uma chamada de API. Significa "já existe uma sessão válida salva,
/// mas o prestador ativou o cadeado biométrico, então precisa confirmar a
/// identidade antes de ver qualquer tela".
class AuthController extends ChangeNotifier {
  AuthController({
    required ApiClient apiClient,
    required TokenStorage tokenStorage,
    required BiometricService biometricService,
  })  : _api = apiClient,
        _storage = tokenStorage,
        _biometric = biometricService {
    _api.tokenProvider = () => _accessToken;
    _api.onUnauthorized = _tryRefresh;
  }

  final ApiClient _api;
  final TokenStorage _storage;
  final BiometricService _biometric;

  AuthStatus status = AuthStatus.unknown;
  String? _accessToken;
  String? _refreshToken;
  String? errorMessage;
  bool isBusy = false;
  bool biometricEnabled = false;

  Future<bool> get biometricAvailable => _biometric.isAvailable;

  /// Chamado uma vez na inicialização do app para restaurar a sessão a
  /// partir do secure storage, sem obrigar o prestador a logar de novo
  /// toda vez que abre o app.
  Future<void> bootstrap() async {
    try {
      // Timeout de segurança: se o canal nativo do secure storage travar
      // (em vez de lançar um erro), isso evita que a splash fique presa
      // para sempre — foi exatamente o sintoma relatado em teste manual.
      _accessToken = await _storage.readAccessToken().timeout(const Duration(seconds: 5));
      _refreshToken = await _storage.readRefreshToken().timeout(const Duration(seconds: 5));
      biometricEnabled =
          await _storage.readBiometricEnabled().timeout(const Duration(seconds: 5));

      if (_accessToken == null) {
        status = AuthStatus.unauthenticated;
      } else if (biometricEnabled) {
        status = AuthStatus.locked;
      } else {
        status = AuthStatus.authenticated;
      }
    } catch (e) {
      // Se a leitura do secure storage falhar (plugin não registrado,
      // keystore indisponível etc.), não deixe o app preso na splash para
      // sempre — trata como "sem sessão salva" e manda para o welcome/login.
      debugPrint('AuthController.bootstrap falhou: $e');
      status = AuthStatus.unauthenticated;
    }
    notifyListeners();
  }

  Future<bool> login(String email, String password) => _submit(() async {
        final result = await _api.post('/auth/login', body: {
          'email': email,
          'password': password,
        });
        await _applyTokens(result);
      });

  Future<bool> register(String name, String email, String password) => _submit(() async {
        final result = await _api.post('/auth/register', body: {
          'name': name,
          'email': email,
          'password': password,
        });
        await _applyTokens(result);
      });

  /// Chamado a partir da tela de bloqueio biométrico. Só existe quando
  /// `status == AuthStatus.locked` (ou seja, já há um access token salvo —
  /// isso apenas confirma a identidade local, sem chamar a API). Retorna o
  /// resultado detalhado (não só bool) para a tela poder explicar o motivo
  /// quando não der certo, em vez de falhar em silêncio.
  Future<BiometricResult> unlockWithBiometrics() async {
    final result = await _biometric.authenticate(
      reason: 'Confirme sua identidade para entrar no PrestadorAki',
    );
    if (result == BiometricResult.success) {
      status = AuthStatus.authenticated;
      notifyListeners();
    }
    return result;
  }

  /// Usado quando o prestador prefere digitar a senha em vez de usar a
  /// biometria na tela de bloqueio — encerra a sessão local e volta para o
  /// fluxo normal de login (mais simples e seguro do que tentar "pular" o
  /// cadeado sem confirmar identidade de nenhuma forma).
  Future<void> useLoginInstead() => logout();

  Future<void> setBiometricEnabled(bool enabled) async {
    biometricEnabled = enabled;
    await _storage.setBiometricEnabled(enabled);
    notifyListeners();
  }

  Future<void> logout() async {
    if (_refreshToken != null) {
      try {
        await _api.post('/auth/logout', body: {'refreshToken': _refreshToken});
      } catch (_) {
        // Mesmo se a chamada falhar (ex.: sem internet), limpamos a sessão
        // localmente — o token vai expirar sozinho no servidor.
      }
    }
    await _storage.clear();
    _accessToken = null;
    _refreshToken = null;
    biometricEnabled = false;
    status = AuthStatus.unauthenticated;
    notifyListeners();
  }

  Future<bool> _tryRefresh() async {
    if (_refreshToken == null) return false;
    try {
      final result = await _api.post('/auth/refresh', body: {'refreshToken': _refreshToken});
      await _applyTokens(result);
      return true;
    } catch (_) {
      await logout();
      return false;
    }
  }

  Future<void> _applyTokens(dynamic result) async {
    _accessToken = result['accessToken'] as String;
    _refreshToken = result['refreshToken'] as String;
    await _storage.save(accessToken: _accessToken!, refreshToken: _refreshToken!);
    status = AuthStatus.authenticated;
  }

  Future<bool> _submit(Future<void> Function() action) async {
    isBusy = true;
    errorMessage = null;
    notifyListeners();
    try {
      await action();
      return true;
    } on ApiException catch (e) {
      errorMessage = e.message;
      return false;
    } catch (e) {
      errorMessage = 'Não foi possível conectar ao servidor.';
      return false;
    } finally {
      isBusy = false;
      notifyListeners();
    }
  }
}
